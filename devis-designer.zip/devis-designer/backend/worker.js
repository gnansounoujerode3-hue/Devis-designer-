/* ============================================================
   Devis Designer — Serveur de validation des codes (Cloudflare Worker)
   ------------------------------------------------------------
   LA solution réelle pour la sécurité : le secret de signature
   n'existe PLUS dans l'application, il vit ici (côté serveur).
   L'app envoie le code saisi → le serveur le valide → répond OK/refus.

   Déploiement (gratuit) :
   1. Créez un compte Cloudflare (gratuit) : https://dash.cloudflare.com
   2. Workers & Pages → Create → Worker → collez ce code → Deploy
   3. Dans le Worker : Settings → Variables → ajoutez :
      - SECRET_KEYS  = "votre-secret-comme-dans-l-app"
      - ADMIN_PASS   = "un-mot-de-passe-long-et-aleatoire"
   4. Dans l'app : src/lib/config.ts → SERVER_URL = "https://votre-worker.workers.dev"

   ⚠️ Le secret ici doit être DIFFÉRENT de celui embarqué dans l'app :
   on peut garder l'ancien pour les vieilles versions, d'où le format
   JSON de SECRET_KEYS (clé = version, valeur = secret).
   ============================================================ */

// Secret(s) de signature, chargés depuis les variables d'environnement.
// Format JSON : { "v1": "secret-1", "v2": "secret-2" }
const SECRET_KEYS = JSON.parse(env('SECRET_KEYS', '{}'));
const ADMIN_PASS = env('ADMIN_PASS', 'change-me');

// Stockage KV (Cloudflare KV) — créez un KV namespace nommé "DD_KV"
// et liez-le au Worker, sinon le serveur fonctionne sans mémoire.
let kv;
try { kv = caches.default; } catch (e) { kv = null; }

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const cors = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };
    if (request.method === 'OPTIONS') return new Response('ok', { headers: cors });

    try {
      /* ---- 1. VALIDER UN CODE (appelé par l'application) ---- */
      if (path === '/validate' && request.method === 'POST') {
        const body = await request.json();
        const code = String(body.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
        const deviceId = String(body.deviceId || '');

        // Vérifier la signature HMAC (même logique que dans l'app)
        const result = await verifyCode(code);
        if (!result.ok) {
          return json({ ok: false, message: result.message }, 400, cors);
        }

        // Anti-réinstallation : quota par appareil côté serveur
        const used = await kvGet(env, 'used:' + deviceId, 0);
        if (used >= 20) {
          return json({ ok: false, message: 'Quota gratuit de 20 exports atteint sur cet appareil.' }, 403, cors);
        }

        // Marquer le code comme utilisé (anti-rejeu)
        const already = await kvGet(env, 'code:' + code, null);
        if (already) {
          return json({ ok: false, message: 'Ce code a deja ete utilise.' }, 403, cors);
        }
        await kvPut(env, 'code:' + code, 'used');

        return json({ ok: true, ...result.license }, 200, cors);
      }

      /* ---- 2. ENREGISTRER UN EXPORT (appelé par l'application) ---- */
      if (path === '/export' && request.method === 'POST') {
        const body = await request.json();
        const deviceId = String(body.deviceId || '');
        const used = await kvGet(env, 'used:' + deviceId, 0);
        await kvPut(env, 'used:' + deviceId, used + 1);
        return json({ ok: true, used: used + 1 }, 200, cors);
      }

      /* ---- 3. ESPACE VENDEUR : générer un code (avec mot de passe) ---- */
      if (path === '/vendor/gen' && request.method === 'POST') {
        const body = await request.json();
        if (body.admin !== ADMIN_PASS) return json({ ok: false, message: 'Non autorise.' }, 401, cors);
        const code = await makeCode(body.kind, body.months || 1);
        return json({ ok: true, code }, 200, cors);
      }

      return json({ ok: false, message: 'Route inconnue.' }, 404, cors);
    } catch (e) {
      return json({ ok: false, message: 'Erreur serveur.' }, 500, cors);
    }
  },
};

/* ---------------- Utilitaires ---------------- */

function json(obj, status, cors) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json', ...cors },
  });
}

function env(name, fallback) {
  try { return globalThis[name] !== undefined ? globalThis[name] : fallback; }
  catch { return fallback; }
}

async function kvGet(env, key, fallback) {
  try {
    const v = await env.DD_KV.get(key);
    return v === null ? fallback : JSON.parse(v);
  } catch { return fallback; }
}

async function kvPut(env, key, value) {
  try { await env.DD_KV.put(key, JSON.stringify(value)); } catch { /* ignore */ }
}

/* ---------------- Base32 (identique à l'app) ---------------- */

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32encode(bytes) {
  let out = '', bits = 0, value = 0;
  for (const b of bytes) {
    value = (value << 8) | b; bits += 8;
    while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}
function b32decode(s) {
  const bytes = []; let bits = 0, value = 0;
  for (const ch of s) {
    const v = B32.indexOf(ch); if (v < 0) continue;
    value = (value << 5) | v; bits += 5;
    if (bits >= 8) { bytes.push((value >>> (bits - 8)) & 255); bits -= 8; }
  }
  return new Uint8Array(bytes);
}
function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return bytes;
}
async function hmacHex(message, secret) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ---------------- Vérification d'un code ---------------- */

async function verifyCode(code) {
  if (!code.startsWith('DD')) return { ok: false, message: 'Code invalide.' };
  const raw = code.slice(2);
  const body = raw.slice(0, -10);
  const sig = raw.slice(-10);

  // Essayer chaque secret (permet la rotation des secrets)
  for (const [version, secret] of Object.entries(SECRET_KEYS)) {
    const expected = b32encode(hexToBytes(await hmacHex(body, secret))).slice(0, 10);
    if (sig === expected) {
      try {
        const payload = JSON.parse(new TextDecoder().decode(b32decode(body)));
        const exp = 30 * 86400000;
        if (!payload.iat || Date.now() - payload.iat > exp) {
          return { ok: false, message: 'Code expire. Contactez le designer.' };
        }
        const kind = payload.kind;
        const now = Date.now();
        const MONTH = 30 * 86400000, YEAR = 365 * 86400000;
        let type, expiresAt = 0, customDesign = false;
        if (kind === 'MONTHLY') { type = 'monthly'; expiresAt = now + (payload.months || 1) * MONTH; }
        else if (kind === 'ANNUAL') { type = 'annual'; expiresAt = now + YEAR; }
        else if (kind === 'ALL') { type = 'all'; expiresAt = now + YEAR; customDesign = true; }
        else if (kind === 'DESIGN') { type = null; customDesign = true; }
        else return { ok: false, message: 'Type de code inconnu.' };
        return { ok: true, license: { type, expiresAt, customDesign } };
      } catch { return { ok: false, message: 'Code illisible.' }; }
    }
  }
  return { ok: false, message: 'Code invalide ou corrompu.' };
}

/* ---------------- Génération d'un code (vendeur) ---------------- */

async function makeCode(kind, months) {
  const payload = { kind, months: kind === 'MONTHLY' ? months : undefined, iat: Date.now() };
  const secret = Object.values(SECRET_KEYS)[Object.keys(SECRET_KEYS).length - 1] || 'default-secret';
  const body = b32encode(new TextEncoder().encode(JSON.stringify(payload)));
  const sig = b32encode(hexToBytes(await hmacHex(body, secret))).slice(0, 10);
  const raw = 'DD' + body + sig;
  return 'DD-' + raw.slice(2).match(/.{1,4}/g).join('-');
}
