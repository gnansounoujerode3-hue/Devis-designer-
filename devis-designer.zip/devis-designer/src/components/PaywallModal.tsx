import { useState } from 'react';
import {
  FREE_EXPORT_LIMIT, PRICE_MONTHLY, PRICE_ANNUAL, PRICE_CUSTOM_DESIGN, PRICE_ALL,
  LicenseState, CodeKind, loadLicense, getExportCount, applyCode, generateCode,
  isLicensed, daysLeft, logVendorCode, getVendorLog, clearVendorLog, codeKindLabel,
} from '../lib/license';
import { VENDOR, CHARIOW_LINKS, VENDOR_PIN, createChariowPayment } from '../lib/config';
import { getMyRefCode, whatsappShareUrl } from '../lib/referral';

interface Props {
  open: boolean;
  onClose: () => void;
  /** true si le blocage vient d'une tentative de création */
  blocked?: boolean;
  onActivated?: () => void;
}

type OfferId = 'monthly' | 'annual' | 'design' | 'all';

const OFFERS: { id: OfferId; title: string; price: number; desc: string; badge?: string; link: string }[] = [
  { id: 'monthly', title: 'Abonnement Mensuel', price: PRICE_MONTHLY, desc: 'Exports PDF et envois signature illimités pendant 1 mois.', badge: 'Populaire', link: CHARIOW_LINKS.MONTHLY },
  { id: 'annual', title: 'Abonnement 1 An', price: PRICE_ANNUAL, desc: 'Exports illimités pendant 1 an. Économisez 2 mois par rapport au mensuel.', link: CHARIOW_LINKS.ANNUAL },
  { id: 'design', title: 'Design Personnalisé', price: PRICE_CUSTOM_DESIGN, desc: 'Un design sur mesure pour VOTRE template, créé pour vous.', link: CHARIOW_LINKS.CUSTOM_DESIGN },
  { id: 'all', title: 'TOUS les Designs (1 an)', price: PRICE_ALL, desc: 'N\'importe quel design de template gratuit pendant 1 an + exports illimités.', badge: 'Best value', link: CHARIOW_LINKS.ALL },
];

const fmt = (n: number) => n.toLocaleString('fr-FR') + ' F';

export default function PaywallModal({ open, onClose, blocked, onActivated }: Props) {
  const [license, setLicense] = useState<LicenseState>(() => loadLicense());
  const [code, setCode] = useState('');
  const [codeMsg, setCodeMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [paying, setPaying] = useState<OfferId | null>(null);
  const [showVendor, setShowVendor] = useState(false);
  const [pin, setPin] = useState('');
  const [vendorOk, setVendorOk] = useState(false);
  const [vendorMsg, setVendorMsg] = useState<string | null>(null);
  const [genMsg, setGenMsg] = useState<string | null>(null);
  const [contactDesign, setContactDesign] = useState(false);
  const [refCopied, setRefCopied] = useState(false);
  const [vendorLog, setVendorLog] = useState(() => getVendorLog());
  const [showLog, setShowLog] = useState(false);

  if (!open) return null;

  const refresh = () => { setLicense(loadLicense()); onActivated?.(); };
  const used = getExportCount();

  const handlePay = async (off: (typeof OFFERS)[number]) => {
    setPaying(off.id);
    try {
      const url = off.link || (await createChariowPayment(off.price, off.title));
      if (url) {
        window.open(url, '_blank');
        setCodeMsg({ ok: true, text: 'Paiement lancé sur Chariow. Après confirmation, entrez le code d\'activation reçu ci-dessous.' });
      } else {
        setCodeMsg({ ok: true, text: `Payez ${fmt(off.price)} via Mobile Money (MTN MoMo / Orange Money / Wave / Moov) au ${VENDOR.PHONE}. Envoyez la référence du paiement par WhatsApp, vous recevrez votre code d'activation.` });
      }
    } finally {
      setPaying(null);
    }
  };

  const handleApplyCode = async () => {
    const r = await applyCode(code);
    setCodeMsg({ ok: r.ok, text: r.message });
    if (r.ok) { refresh(); setCode(''); }
  };

  const handleVendorPin = () => {
    if (pin === VENDOR_PIN) { setVendorOk(true); setVendorMsg(null); }
    else setVendorMsg('PIN incorrect.');
  };

  const handleGen = async (kind: CodeKind, months = 1) => {
    const c = await generateCode(kind, months);
    logVendorCode(kind, kind === 'MONTHLY' ? months : undefined, c);
    setGenMsg(c);
    setVendorLog(getVendorLog());
    navigator.clipboard?.writeText(c).catch(() => {});
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-2xl bg-white dark:bg-zinc-900 shadow-2xl" onClick={e => e.stopPropagation()}>
        {/* En-tête */}
        <div className="p-6 pb-4 border-b border-[#F0F0F0] dark:border-zinc-800 flex items-start justify-between">
          <div>
            <h2 className="text-xl font-black text-[#111] dark:text-white">
              {blocked ? 'Limite d\'exports gratuits atteinte ' : 'Devis Designer Pro'}
            </h2>
            <p className="text-sm text-[#888] mt-1">
              {isLicensed(license)
                ? ` Abonnement actif — reste ${daysLeft(license)} jour(s)`
                : `${Math.min(used, FREE_EXPORT_LIMIT)} / ${FREE_EXPORT_LIMIT} exports gratuits utilisés${blocked ? ' — passez à Pro pour continuer' : ''}`}
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-[#F0F0F0] dark:hover:bg-zinc-800 flex items-center justify-center text-[#999]"></button>
        </div>

        <div className="p-6 space-y-6">
          {/* Offres */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {OFFERS.map(o => (
              <div key={o.id} className={`relative rounded-xl border-2 p-4 flex flex-col ${o.badge ? 'border-[#0057FF] dark:border-blue-500' : 'border-[#ECECEC] dark:border-zinc-700'}`}>
                {o.badge && <span className="absolute -top-2.5 left-3 text-[9px] font-black px-2 py-0.5 rounded-full bg-[#0057FF] text-white tracking-wider uppercase">{o.badge}</span>}
                <div className="text-[11px] font-bold tracking-widest text-[#999] uppercase">{o.title}</div>
                <div className="text-2xl font-black mt-1" style={{ color: '#0057FF' }}>{fmt(o.price)}</div>
                <div className="text-[11px] text-[#777] dark:text-zinc-400 mt-1 flex-1">{o.desc}</div>
                <button
                  onClick={() => handlePay(o)}
                  disabled={paying === o.id}
                  className="mt-3 w-full h-9 rounded-lg bg-[#0057FF] text-white text-xs font-bold hover:opacity-90 active:scale-[0.98] disabled:opacity-50"
                >
                  {paying === o.id ? '...' : `Payer via Chariow (Mobile Money)`}
                </button>
              </div>
            ))}
          </div>

          {/* Saisie de code d'activation */}
          <div className="rounded-xl bg-[#F8F8FF] dark:bg-zinc-800/50 border border-[#E8E8FF] dark:border-zinc-700 p-4">
            <div className="text-xs font-black tracking-widest text-[#111] dark:text-white mb-1">DÉJÀ ABONNÉ ?</div>
            <div className="text-[11px] text-[#888] mb-3">Entrez le code d'activation reçu par WhatsApp / SMS après votre paiement.</div>
            <div className="flex gap-2">
              <input
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                placeholder="DD-XXXX-XXXX-XXXX"
                className="flex-1 px-3 py-2.5 text-sm rounded-lg border border-[#E0E0E0] dark:border-zinc-700 dark:bg-zinc-900 dark:text-white font-mono tracking-wider focus:outline-none focus:border-[#0057FF]"
              />
              <button onClick={handleApplyCode} className="px-5 rounded-lg bg-[#111] dark:bg-white text-white dark:text-black text-xs font-bold hover:opacity-90">Activer</button>
            </div>
            {codeMsg && (
              <div className={`mt-2 text-[11px] font-medium ${codeMsg.ok ? 'text-green-600 dark:text-green-400' : 'text-red-500'}`}>{codeMsg.text}</div>
            )}

          </div>

          {/* Design personnalisé acheté : contact */}
          {license.customDesign && !contactDesign && (
            <button onClick={() => setContactDesign(true)} className="w-full rounded-xl border-2 border-dashed border-[#0057FF]/40 p-3 text-xs font-bold text-[#0057FF] hover:bg-blue-50 dark:hover:bg-blue-950/30">
              Design personnalisé débloqué — contacter le designer
            </button>
          )}
          {contactDesign && (
            <div className="rounded-xl border border-green-200 dark:border-green-900 bg-green-50 dark:bg-green-950/30 p-4">
              <div className="text-xs font-black text-green-700 dark:text-green-400 mb-2">Votre design personnalisé</div>
              <p className="text-[11px] text-[#666] dark:text-zinc-300 mb-3">Décrivez votre design (couleurs, logo, mise en page…) et envoyez-le au designer :</p>
              <a href={VENDOR.WHATSAPP} target="_blank" rel="noreferrer" className="block w-full text-center py-2.5 rounded-lg bg-[#25D366] text-white text-xs font-bold hover:opacity-90 mb-2">WhatsApp — décrire mon design</a>
              <div className="text-center text-[11px] text-[#888]">ou appelez : <b>{VENDOR.PHONE}</b></div>
            </div>
          )}

          {/* Recommandation — partage de l'app */}
          <div className="rounded-xl border-2 border-dashed border-[#0057FF]/30 p-4">
            <div className="text-xs font-black tracking-widest text-[#111] dark:text-white mb-1">RECOMMANDER L'APPLICATION</div>
            <p className="text-[11px] text-[#888] mb-3">
              Partagez Devis Designer avec vos collègues et clients. Votre code parrain les fait bénéficier de l'app.
            </p>
            <div className="flex items-center gap-2 mb-2">
              <div className="flex-1 font-mono font-black tracking-widest text-[#0057FF] bg-blue-50 dark:bg-blue-950/40 rounded-lg py-2 text-center">{getMyRefCode()}</div>
              <button
                onClick={() => { navigator.clipboard?.writeText(getMyRefCode()).catch(() => {}); setRefCopied(true); setTimeout(() => setRefCopied(false), 1500); }}
                className="px-3 py-2 rounded-lg border border-[#BFDBFE] text-[11px] font-bold text-[#0057FF] hover:bg-blue-50 dark:hover:bg-blue-950/40"
              >
                {refCopied ? 'Copié' : 'Copier'}
              </button>
            </div>
            <a href={whatsappShareUrl()} target="_blank" rel="noreferrer" className="block w-full text-center py-2.5 rounded-lg bg-[#25D366] text-white text-xs font-bold hover:opacity-90">
              Recommander sur WhatsApp
            </a>
          </div>

          {/* Espace vendeur */}
          {!showVendor ? (
            <button onClick={() => setShowVendor(true)} className="w-full text-center text-[10px] text-[#BBB] hover:text-[#666] dark:hover:text-zinc-400 tracking-widest uppercase">Espace vendeur</button>
          ) : !vendorOk ? (
            <div className="rounded-xl border border-[#ECECEC] dark:border-zinc-700 p-4">
              <div className="text-xs font-black tracking-widest mb-2 text-[#111] dark:text-white">ESPACE VENDEUR</div>
              {VENDOR_PIN === '2468' && (
                <div className="mb-2 text-[10px] font-bold text-red-500 bg-red-50 dark:bg-red-950/30 rounded-lg px-2 py-1.5">
                  Attention : le PIN par defaut (2468) n'a pas ete change. Modifiez VENDOR_PIN dans src/lib/config.ts avant toute distribution.
                </div>
              )}
              <div className="flex gap-2">
                <input type="password" value={pin} onChange={e => setPin(e.target.value)} placeholder="PIN" className="w-32 px-3 py-2 rounded-lg border border-[#E0E0E0] dark:border-zinc-700 dark:bg-zinc-900 dark:text-white text-sm focus:outline-none" />
                <button onClick={handleVendorPin} className="px-4 rounded-lg bg-[#111] dark:bg-white text-white dark:text-black text-xs font-bold">Entrer</button>
              </div>
              {vendorMsg && <div className="mt-2 text-[11px] text-red-500">{vendorMsg}</div>}
            </div>
          ) : (
            <div className="rounded-xl border border-[#ECECEC] dark:border-zinc-700 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-xs font-black tracking-widest text-[#111] dark:text-white">GÉNÉRER UN CODE</div>
                <button onClick={() => { setVendorOk(false); setPin(''); }} className="text-[10px] text-[#999] hover:text-red-500">Se déconnecter</button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button onClick={() => handleGen('MONTHLY', 1)} className="py-2 rounded-lg bg-[#0057FF] text-white text-[10px] font-bold hover:opacity-90">1 mois (2000 F)</button>
                <button onClick={() => handleGen('MONTHLY', 12)} className="py-2 rounded-lg bg-[#0057FF]/80 text-white text-[10px] font-bold hover:opacity-90">12 mois</button>
                <button onClick={() => handleGen('ANNUAL')} className="py-2 rounded-lg bg-[#111] dark:bg-white text-white dark:text-black text-[10px] font-bold hover:opacity-90">1 an (15 000 F)</button>
                <button onClick={() => handleGen('DESIGN')} className="py-2 rounded-lg bg-[#10B981] text-white text-[10px] font-bold hover:opacity-90">Design (5 000 F)</button>
                <button onClick={() => handleGen('ALL')} className="col-span-2 py-2 rounded-lg bg-[#8B5CF6] text-white text-[10px] font-bold hover:opacity-90">Tous designs 1 an (50 000 F)</button>
                <button onClick={() => { setGenMsg(null); navigator.clipboard?.writeText(genMsg || '').catch(() => {}); }} className="col-span-2 py-2 rounded-lg border border-[#E0E0E0] dark:border-zinc-700 text-[10px] font-bold text-[#666] hover:bg-[#F8F8F8] dark:hover:bg-zinc-800">Copier le dernier code</button>
              </div>
              {genMsg && (
                <div className="bg-[#F0F0F0] dark:bg-zinc-800 rounded-lg p-3 text-center">
                  <div className="text-[10px] text-[#999] mb-1">Code généré (envoyez-le au client) :</div>
                  <div className="font-mono font-black text-lg tracking-widest text-[#111] dark:text-white">{genMsg}</div>
                </div>
              )}
              <div className="text-[10px] text-[#999]">Stats installation : {used} export(s) utilisé(s) · statut : {license.type}</div>

              {/* Historique des codes générés (suivi des ventes) */}
              <div className="border-t border-[#ECECEC] dark:border-zinc-700 pt-3">
                <div className="flex items-center justify-between mb-2">
                  <button onClick={() => setShowLog(v => !v)} className="text-[11px] font-black tracking-widest text-[#111] dark:text-white hover:text-[#0057FF]">
                    HISTORIQUE ({vendorLog.length})
                  </button>
                  {vendorLog.length > 0 && (
                    <button onClick={() => { clearVendorLog(); setVendorLog([]); }} className="text-[10px] text-red-400 hover:text-red-600">
                      Tout effacer
                    </button>
                  )}
                </div>
                {showLog && (
                  vendorLog.length === 0 ? (
                    <div className="text-[10px] text-[#BBB] py-2 text-center">Aucun code généré pour l'instant.</div>
                  ) : (
                    <div className="max-h-48 overflow-y-auto rounded-lg border border-[#F0F0F0] dark:border-zinc-800 divide-y divide-[#F5F5F5] dark:divide-zinc-800">
                      {vendorLog.map((e, i) => (
                        <div key={i} className="px-2.5 py-2 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <div className="text-[11px] font-bold text-[#111] dark:text-white truncate">{codeKindLabel(e.kind, e.months)}</div>
                            <div className="text-[9px] text-[#999] font-mono truncate">{e.code}</div>
                          </div>
                          <span className="text-[9px] text-[#AAA] whitespace-nowrap">{new Date(e.at).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      ))}
                    </div>
                  )
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
