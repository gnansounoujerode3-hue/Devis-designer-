# Devis Designer — Application Web

Générateur de devis et factures professionnels en SVG/PDF, **100 % web** :
aucune installation, accessible depuis n'importe quel navigateur (PC, téléphone, tablette),
mises à jour automatiques.

## Démarrage rapide

```bash
npm install        # installer les dépendances
npm run dev        # serveur de développement (http://localhost:5173)
npm run build      # build de production (fichier unique dist/index.html)
npm run preview    # prévisualiser le build
```

## Fonctionnalités

- **12 templates de devis/factures** personnalisables (couleurs, polices, logo, conditions)
- **Édition directe** : toucher/cliquer un texte sur l'aperçu pour le modifier (n'importe quel texte)
- **Signatures** manuscrites (émetteur + client), envoi pour signature
- **Export** : PDF (A4 multipages), SVG, présentation plein écran
- **Sauvegarde / restauration** JSON (export/import de tous les devis + clients)
- **Monétisation intégrée** : 20 exports gratuits, abonnements 2000 F/mois, 15 000 F/an,
  design personnalisé 5 000 F, tous les designs 50 000 F/an (activation par codes)
- **Concours** : partagez votre meilleur devis sur WhatsApp → 3 mois gratuits
- **FAQ, CGU et politique de confidentialité** intégrés (conforme loi n°2017-20 Bénin)
- **Rappel d'expiration** d'abonnement, carnet de clients, filigrane de statut

## Structure

```
devis-designer/
├── index.html          # Point d'entrée
├── package.json        # Dépendances & scripts
├── vite.config.ts      # Configuration Vite (fichier unique)
├── tsconfig.json       # TypeScript strict
├── backend/
│   └── worker.js       # Serveur de validation des codes (Cloudflare Worker, optionnel)
└── src/
    ├── main.tsx        # Bootstrap React
    ├── App.tsx         # Composant racine
    ├── components/     # Paywall, FAQ, Legal, Onboarding, SharePrompt, SignatureModal...
    ├── templates/      # Les 12 templates SVG
    ├── lib/            # license (quota/codes), referral (parrainage), config, store...
    ├── store.ts        # Persistance localStorage + sauvegarde JSON
    ├── types.ts        # Types partagés
    └── assets/         # Logo
```

## 💰 Monétisation

| Offre | Prix | Effet |
|---|---|---|
| Gratuit | 0 F | **20 exports PDF / envois signature** par installation (la création de devis est libre) |
| Abonnement mensuel | 2 000 F / mois | Exports illimités pendant 1 mois (cumulable) |
| Abonnement 1 an | 15 000 F / an | Exports illimités pendant 1 an |
| Design personnalisé | 5 000 F | Un design sur mesure pour votre template (paiement unique) |
| TOUS les designs (1 an) | 50 000 F / an | N'importe quel design de template gratuit pendant 1 an + exports illimités |

### Comment ça marche (sans serveur)
1. Le client crée ses devis librement. Chaque **export PDF** ou **envoi pour signature** consomme 1 des 20 gratuits.
2. Épuisé → le client paie via **Chariow** (Mobile Money : MTN MoMo, Orange Money, Wave, Moov — commission 15 %).
3. Vous générez un **code d'activation** depuis l'app : paywall → « Espace vendeur » → PIN (`2468` par défaut) → choisir l'offre.
4. Vous envoyez le code au client (WhatsApp/SMS). Il le saisit dans « Déjà abonné ? » → licence activée immédiatement.

### Personnalisation (`src/lib/config.ts`)
- `VENDOR.PHONE` / `VENDOR.WHATSAPP` / `VENDOR.EMAIL` : vos coordonnées
- `VENDOR_PIN` : PIN de l'espace vendeur (**à changer avant lancement !**)
- `VENDOR.DOWNLOAD_LINK` : l'URL de votre application web (pour les messages de partage)
- `CHARIOW_LINKS` : liens de paiement Chariow par produit (MONTHLY 2000 F, ANNUAL 15000 F, CUSTOM_DESIGN 5000 F, ALL 50000 F)
- `CHARIOW_API.KEY` : clé API Chariow pour paiements automatiques (⚠️ CORS : via un mini serveur)

## 🌐 Déploiement web

Le build produit **un seul fichier** `dist/index.html` (tout inliné : JS, CSS, logo, favicon).
Il peut être hébergé **n'importe où** :

### Option 1 — Vercel (recommandé, gratuit)
```bash
npm run deploy
```
Ou via le tableau de bord vercel.com : importez le dépôt, framework = Vite, build = `npm run build`, output = `dist`.

### Option 2 — Netlify (gratuit)
- Glissez-déposez le dossier `dist/` sur app.netlify.com/drop
- Ou connectez votre dépôt : build `npm run build`, publish `dist`

### Option 3 — Hébergement classique (OVH, Hostinger, etc.)
- Téléversez `dist/index.html` (et le dossier `dist/` entier) sur votre espace web
- L'application est un fichier unique : pas de serveur, pas de configuration

### Option 4 — GitHub Pages
```bash
npm run build
npx gh-pages -d dist
```

## 🔐 Sécurité

### Couche 1 — Durcissement local (déjà actif)
- Secret encodé (base64) · codes valables 30 jours · anti-brute-force (5 échecs → 1h)
- Compteur d'exports à double emplacement (localStorage + IndexedDB)
- Alerte PIN par défaut dans l'espace vendeur

### Couche 2 — Serveur de validation (`backend/worker.js`, optionnel)
Cloudflare Worker **gratuit** (100k requêtes/jour) : validation des codes côté serveur,
anti-rejeu, quota par appareil. Voir le fichier pour les instructions de déploiement.

## 🎁 Partage & concours (3 mois gratuits)

| Mécanisme | Détail |
|---|---|
| **Code parrain** | Chaque installation a un code unique `DDREF-XXXX` |
| **Partage WhatsApp 1 clic** | Boutons « Recommander sur WhatsApp » avec message pré-écrit + lien web |
| **CONCOURS — 3 mois gratuits** | Après un export réussi : 1) publier son meilleur devis sur son statut WhatsApp 2) recommander l'app 3) confirmer → code récompense **+3 mois** (1 seule fois) |
| **Lien `?ref=`** | `https://votre-app/?ref=DDREF-XXXX` pré-remplit le code parrain à l'arrivée |
| **Bannière quota bas** | Quand il reste ≤ 5 exports gratuits → bandeau d'urgence avec bouton partager |

## Notes

- **Données** : stockées dans le navigateur (localStorage). Encourager la sauvegarde JSON
  (barre « SAUVEGARDE » sur la page d'accueil) — indispensable sur le web partagé.
- **Responsive** : interface optimisée PC et mobile (header compact, tap pour éditer, boutons visibles au toucher).
- **QR** : retiré de tous les templates (exigence utilisateur).
- **Aucun emoji** dans l'interface (exigence utilisateur).
